package com.edumoises.minhasfinacas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhasfinacasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhasfinacasApplication.class, args);
	}

}
