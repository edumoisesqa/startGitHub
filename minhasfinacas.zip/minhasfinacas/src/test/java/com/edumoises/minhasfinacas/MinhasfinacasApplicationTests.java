package com.edumoises.minhasfinacas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhasfinacasApplicationTests {

	@Test
	void contextLoads() {
	}

}
